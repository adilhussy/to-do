import { parks } from '@/data/parks';
import Layout from '@/components/Layout';
import Link from 'next/link';

export default function Boroughs() {
  // Group parks by borough
  const boroughGroups = {
    'M': { name: 'Manhattan', parks: [] },
    'B': { name: 'Brooklyn', parks: [] },
    'Q': { name: 'Queens', parks: [] },
    'X': { name: 'Bronx', parks: [] },
    'R': { name: 'Staten Island', parks: [] }
  };
  
  // Count parks by borough
  parks.forEach(park => {
    if (boroughGroups[park.borough]) {
      boroughGroups[park.borough].parks.push(park);
    }
  });
  
  return (
    <Layout>
      <div className="container mx-auto px-4 py-8">
        <h1 className="text-3xl font-bold text-center mb-8">Dog Parks by Borough</h1>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {Object.entries(boroughGroups).map(([code, data]) => (
            <div key={code} className="bg-white rounded-lg shadow-md overflow-hidden hover:shadow-lg transition-shadow duration-300">
              <Link href={`/boroughs/${data.name.toLowerCase()}`}>
                <div className="p-6">
                  <h2 className="text-2xl font-semibold text-gray-900">{data.name}</h2>
                  <p className="text-gray-600 mt-2">{data.parks.length} dog parks</p>
                  
                  <div className="mt-4">
                    <span className="inline-block bg-blue-100 text-blue-800 px-3 py-1 rounded-full text-sm font-medium">
                      View All Parks
                    </span>
                  </div>
                </div>
              </Link>
            </div>
          ))}
        </div>
        
        <div className="mt-12 bg-gray-100 rounded-lg p-6">
          <h2 className="text-2xl font-semibold mb-4">About New York City Dog Parks</h2>
          <p className="text-gray-700 mb-4">
            New York City is home to over 100 dog parks and off-leash areas across its five boroughs. 
            These parks provide essential spaces for dogs to exercise, socialize, and play freely in an urban environment.
          </p>
          <p className="text-gray-700 mb-4">
            Each borough offers unique dog park experiences, from the bustling parks of Manhattan to the 
            spacious runs in Queens and Brooklyn. Many parks feature amenities such as separate areas for small dogs, 
            water fountains, and various surface types to accommodate different preferences.
          </p>
          <p className="text-gray-700">
            Use our directory to find the perfect dog park for you and your furry friend, with detailed information 
            about amenities, off-leash hours, and locations throughout the city.
          </p>
        </div>
      </div>
    </Layout>
  );
}
