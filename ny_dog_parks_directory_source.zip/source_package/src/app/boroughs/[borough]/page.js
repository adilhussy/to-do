import { useParams } from 'next/router';
import { useState, useEffect } from 'react';
import { parks } from '@/data/parks';
import Layout from '@/components/Layout';
import ParkList from '@/components/ParkList';
import ParkMap from '@/components/ParkMap';

export default function BoroughPage() {
  const { borough } = useParams();
  const [boroughParks, setBoroughParks] = useState([]);
  const [boroughName, setBoroughName] = useState('');
  
  useEffect(() => {
    if (borough) {
      // Convert borough name to code
      const boroughMap = {
        'manhattan': 'M',
        'brooklyn': 'B',
        'queens': 'Q',
        'bronx': 'X',
        'staten-island': 'R'
      };
      
      // Get the borough code
      const code = boroughMap[borough.toLowerCase()];
      
      // Set the full borough name
      const fullNames = {
        'M': 'Manhattan',
        'B': 'Brooklyn',
        'Q': 'Queens',
        'X': 'Bronx',
        'R': 'Staten Island'
      };
      
      setBoroughName(fullNames[code] || borough);
      
      // Filter parks by borough
      const filteredParks = parks.filter(park => park.borough === code);
      setBoroughParks(filteredParks);
    }
  }, [borough]);

  return (
    <Layout>
      <div className="container mx-auto px-4 py-8">
        <h1 className="text-3xl font-bold text-center mb-8">
          Dog Parks in {boroughName}
        </h1>
        
        <div className="mb-8">
          <ParkMap parks={boroughParks} />
        </div>
        
        <div className="mb-8">
          <h2 className="text-2xl font-semibold mb-4">
            {boroughParks.length} Dog Parks in {boroughName}
          </h2>
          <ParkList parks={boroughParks} />
        </div>
        
        <div className="bg-gray-100 rounded-lg p-6">
          <h2 className="text-2xl font-semibold mb-4">About {boroughName} Dog Parks</h2>
          
          {borough === 'manhattan' && (
            <p className="text-gray-700 mb-4">
              Manhattan offers a variety of dog parks and off-leash areas despite its urban density. 
              From the famous dog runs in Central Park to neighborhood gems like Tompkins Square Dog Run, 
              Manhattan's dog parks provide essential recreation spaces for the borough's many canine residents.
            </p>
          )}
          
          {borough === 'brooklyn' && (
            <p className="text-gray-700 mb-4">
              Brooklyn features some of NYC's most popular dog parks, including Prospect Park's designated 
              off-leash areas and the spacious Hillside Dog Park. The borough's dog-friendly spaces range from 
              small neighborhood runs to large park areas with varied terrain and amenities.
            </p>
          )}
          
          {borough === 'queens' && (
            <p className="text-gray-700 mb-4">
              Queens dog parks offer more space than many other boroughs, with notable locations like 
              Cunningham Park Dog Run and Sherry Park Dog Run. Many Queens dog parks feature natural settings 
              and ample room for dogs to run and play.
            </p>
          )}
          
          {borough === 'bronx' && (
            <p className="text-gray-700 mb-4">
              The Bronx provides several excellent dog parks, including those in Pelham Bay Park and 
              Bronx River Park. These spaces often feature natural surroundings and fewer crowds than 
              Manhattan or Brooklyn alternatives.
            </p>
          )}
          
          {borough === 'staten-island' && (
            <p className="text-gray-700 mb-4">
              Staten Island dog parks tend to be more spacious and less crowded than those in other boroughs. 
              Notable locations include Wolfe's Pond Park Dog Run and South Beach Dog Run, offering plenty of 
              space for dogs to exercise and play.
            </p>
          )}
          
          <p className="text-gray-700">
            Remember to follow all dog park rules, including keeping your dog's vaccinations current, 
            cleaning up after your pet, and monitoring their behavior with other dogs. Most NYC dog parks 
            require dogs to be licensed with the city.
          </p>
        </div>
      </div>
    </Layout>
  );
}
