import Layout from '@/components/Layout';

export default function About() {
  return (
    <Layout>
      <div className="container mx-auto px-4 py-8">
        <h1 className="text-3xl font-bold text-center mb-8">About NYC Dog Parks Directory</h1>
        
        <div className="max-w-3xl mx-auto bg-white rounded-lg shadow-md p-6">
          <h2 className="text-2xl font-semibold mb-4">Our Mission</h2>
          <p className="text-gray-700 mb-6">
            The NYC Dog Parks Directory was created to help dog owners in New York City find the perfect park for their furry friends. 
            With over 100 dog parks and off-leash areas across the five boroughs, we aim to provide the most comprehensive and 
            up-to-date information about each location, including amenities, off-leash hours, and more.
          </p>
          
          <h2 className="text-2xl font-semibold mb-4">Features</h2>
          <ul className="list-disc pl-6 mb-6 space-y-2 text-gray-700">
            <li>Comprehensive database of 100+ dog parks across all five NYC boroughs</li>
            <li>Detailed information about amenities like water fountains, separate small dog areas, and shade</li>
            <li>Interactive map to easily locate dog parks near you</li>
            <li>Advanced filtering to find parks with specific features</li>
            <li>Borough-specific pages for targeted exploration</li>
            <li>Mobile-friendly design for on-the-go access</li>
          </ul>
          
          <h2 className="text-2xl font-semibold mb-4">Data Sources</h2>
          <p className="text-gray-700 mb-6">
            Our directory combines data from multiple authoritative sources, including:
          </p>
          <ul className="list-disc pl-6 mb-6 space-y-2 text-gray-700">
            <li>NYC Open Data's "Directory of Dog Runs and Off-Leash Areas"</li>
            <li>NYC Parks Department official information</li>
            <li>User contributions and reviews</li>
            <li>On-site verification of amenities and features</li>
          </ul>
          
          <h2 className="text-2xl font-semibold mb-4">Dog Park Etiquette</h2>
          <p className="text-gray-700 mb-4">
            When visiting NYC dog parks, please remember to follow these guidelines:
          </p>
          <ul className="list-disc pl-6 mb-6 space-y-2 text-gray-700">
            <li>Keep your dog's vaccinations current and carry proof of rabies vaccination</li>
            <li>Ensure your dog is licensed with the NYC Department of Health</li>
            <li>Always clean up after your dog</li>
            <li>Monitor your dog's behavior and intervene if play becomes too rough</li>
            <li>Respect posted rules and off-leash hours</li>
            <li>Do not bring food into dog parks</li>
            <li>Keep small children closely supervised</li>
          </ul>
          
          <h2 className="text-2xl font-semibold mb-4">Contact Us</h2>
          <p className="text-gray-700">
            Have suggestions for improving our directory? Found a dog park that's not listed? 
            Please contact us at <span className="text-blue-600">info@nycdogparks.com</span> with your feedback.
          </p>
        </div>
      </div>
    </Layout>
  );
}
