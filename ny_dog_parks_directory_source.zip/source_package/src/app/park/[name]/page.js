import { useParams } from 'next/router';
import { useState, useEffect } from 'react';
import { parks } from '@/data/parks';
import Layout from '@/components/Layout';
import Link from 'next/link';
import { MapContainer, TileLayer, Marker, Popup } from 'react-leaflet';
import 'leaflet/dist/leaflet.css';
import 'leaflet-defaulticon-compatibility/dist/leaflet-defaulticon-compatibility.css';
import "leaflet-defaulticon-compatibility";

export default function ParkDetail() {
  const { name } = useParams();
  const [park, setPark] = useState(null);
  
  useEffect(() => {
    if (name) {
      const foundPark = parks.find(p => p.name === decodeURIComponent(name));
      setPark(foundPark);
    }
  }, [name]);

  if (!park) {
    return (
      <Layout>
        <div className="container mx-auto px-4 py-8">
          <div className="text-center py-12">
            <h1 className="text-2xl font-semibold text-gray-900">Park not found</h1>
            <p className="mt-2 text-gray-600">The dog park you're looking for doesn't exist or has been removed.</p>
            <Link href="/" className="mt-4 inline-block bg-blue-600 text-white px-4 py-2 rounded-md hover:bg-blue-700 transition-colors">
              Return to Home
            </Link>
          </div>
        </div>
      </Layout>
    );
  }

  // Function to convert borough code to full name
  const getBoroughName = (code) => {
    const boroughs = {
      'M': 'Manhattan',
      'B': 'Brooklyn',
      'Q': 'Queens',
      'X': 'Bronx',
      'R': 'Staten Island'
    };
    return boroughs[code] || code;
  };

  // Function to extract coordinates from park data
  const getCoordinates = (park) => {
    // If we have explicit coordinates in our data
    if (park.location.coordinates && 
        park.location.coordinates.latitude && 
        park.location.coordinates.longitude) {
      return [
        parseFloat(park.location.coordinates.latitude),
        parseFloat(park.location.coordinates.longitude)
      ];
    }
    
    // Default coordinates based on borough if specific coordinates aren't available
    const boroughCoordinates = {
      'M': [40.7831, -73.9712], // Manhattan
      'B': [40.6782, -73.9442], // Brooklyn
      'Q': [40.7282, -73.7949], // Queens
      'X': [40.8448, -73.8648], // Bronx
      'R': [40.5795, -74.1502]  // Staten Island
    };
    
    return boroughCoordinates[park.borough] || [40.7128, -74.0060]; // Default to NYC
  };

  // Function to render amenity details
  const renderAmenityDetail = (label, value) => {
    if (!value || value === 'Unknown') return null;
    
    const getIcon = (val) => {
      if (val === 'Yes') return '✅';
      if (val === 'No') return '❌';
      return '📌';
    };
    
    return (
      <div className="flex items-center py-2 border-b border-gray-200">
        <span className="mr-2">{getIcon(value)}</span>
        <span className="font-medium">{label}:</span>
        <span className="ml-2">{value === 'Yes' ? 'Available' : value}</span>
      </div>
    );
  };

  const coordinates = getCoordinates(park);

  return (
    <Layout>
      <div className="container mx-auto px-4 py-8">
        <div className="mb-6">
          <Link href="/" className="text-blue-600 hover:text-blue-800 transition-colors">
            &larr; Back to all parks
          </Link>
        </div>
        
        <div className="bg-white rounded-lg shadow-lg overflow-hidden">
          <div className="p-6">
            <h1 className="text-3xl font-bold text-gray-900">{park.name}</h1>
            <p className="text-xl text-gray-600 mt-2">{getBoroughName(park.borough)}</p>
            
            {park.location.zip_code && (
              <p className="text-gray-500 mt-1">ZIP Code: {park.location.zip_code}</p>
            )}
            
            <div className="mt-8 grid grid-cols-1 md:grid-cols-2 gap-8">
              <div>
                <h2 className="text-xl font-semibold mb-4">Park Details</h2>
                
                {park.amenities.off_leash_hours && park.amenities.off_leash_hours !== 'Unknown' && (
                  <div className="bg-green-100 text-green-800 px-4 py-3 rounded-md mb-6">
                    <span className="font-medium">Off-leash hours:</span> {park.amenities.off_leash_hours}
                  </div>
                )}
                
                <div className="space-y-1">
                  {renderAmenityDetail('Water Fountain', park.amenities.water_fountain)}
                  {renderAmenityDetail('Separate Small Dog Area', park.amenities.separate_small_dog_area)}
                  {renderAmenityDetail('Shade', park.amenities.shade)}
                  {renderAmenityDetail('Waste Bags Provided', park.amenities.waste_bags_provided)}
                  {renderAmenityDetail('Fenced', park.amenities.fenced)}
                  {renderAmenityDetail('Surface Type', park.amenities.surface_type)}
                  {renderAmenityDetail('Lighting', park.amenities.lighting)}
                  {renderAmenityDetail('Seating', park.amenities.seating)}
                </div>
                
                {park.rules && park.rules.length > 0 && (
                  <div className="mt-8">
                    <h2 className="text-xl font-semibold mb-4">Park Rules</h2>
                    <ul className="list-disc pl-5 space-y-2">
                      {park.rules.map((rule, index) => (
                        <li key={index} className="text-gray-700">{rule}</li>
                      ))}
                    </ul>
                  </div>
                )}
                
                {park.notes && (
                  <div className="mt-8">
                    <h2 className="text-xl font-semibold mb-4">Notes</h2>
                    <p className="text-gray-700">{park.notes}</p>
                  </div>
                )}
              </div>
              
              <div>
                <h2 className="text-xl font-semibold mb-4">Location</h2>
                <div className="h-[400px] rounded-lg overflow-hidden shadow-md">
                  <MapContainer 
                    center={coordinates} 
                    zoom={15} 
                    style={{ height: '100%', width: '100%' }}
                    scrollWheelZoom={false}
                  >
                    <TileLayer
                      attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
                      url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
                    />
                    <Marker position={coordinates}>
                      <Popup>
                        <div>
                          <h3 className="font-semibold">{park.name}</h3>
                          <p>{getBoroughName(park.borough)}</p>
                        </div>
                      </Popup>
                    </Marker>
                  </MapContainer>
                </div>
                
                <div className="mt-6">
                  <h2 className="text-xl font-semibold mb-4">Nearby Dog Parks</h2>
                  <div className="space-y-3">
                    {parks
                      .filter(p => p.borough === park.borough && p.name !== park.name)
                      .slice(0, 3)
                      .map((nearbyPark) => (
                        <Link 
                          key={nearbyPark.name} 
                          href={`/park/${encodeURIComponent(nearbyPark.name)}`}
                          className="block bg-gray-100 p-4 rounded-md hover:bg-gray-200 transition-colors"
                        >
                          <h3 className="font-medium text-gray-900">{nearbyPark.name}</h3>
                          <p className="text-sm text-gray-600 mt-1">
                            {getBoroughName(nearbyPark.borough)}
                          </p>
                        </Link>
                      ))
                    }
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </Layout>
  );
}
