import { enhanced_parks } from './enhanced_parks.json';

// Export the parks data for use throughout the application
export const parks = enhanced_parks;
